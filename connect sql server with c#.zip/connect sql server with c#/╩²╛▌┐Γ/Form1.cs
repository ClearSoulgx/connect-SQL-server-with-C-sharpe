﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;

namespace 数据库
{
    public partial class Form1 : Form
    {
        String SNO;
        String PNO;
        String  QLT;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            String connsql = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=Spj;Integrated Security=True";
            try
            {


                using (SqlConnection conn = new SqlConnection())
                {
                    conn.ConnectionString = connsql;
                    conn.Open();
                    String sql = "SELECT * FROM SP";
                    SqlDataAdapter myda = new SqlDataAdapter(sql, conn); // 实例化适配器
                    DataTable dt = new DataTable(); // 实例化数据表
                    myda.Fill(dt); // 保存数据 
                    dataGridView1.DataSource = dt; // 设置到DataGridView中
                    for (int i = 0; i < dataGridView1.ColumnCount; i++)
                    {
                        dataGridView1.Columns[i].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
                    }
                    conn.Close(); // 关闭数据库连接
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("错误信息：" + ex.Message, "出现错误");
            }




        }

      

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click_1(object sender, EventArgs e)
        {

            String connsql = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=Spj;Integrated Security=True";
            try
            {


                using (SqlConnection conn = new SqlConnection())
                {
                    conn.ConnectionString = connsql;
                    conn.Open();
                    SNO = this.textBox1.Text;
                    PNO = this.textBox2.Text;
                    QLT = this.textBox3.Text;
                    String sql = "DECLARE @retstat int;EXECUTE @retstat = SPPROCE" + "'" + SNO + "'" + "," + "'" + PNO + "'" + "," + "'J1'," + QLT+ "IF @retstat = 0 SELECT 'Sales success' ELSE SELECT 'Sales failed'";
                    SqlDataAdapter myda = new SqlDataAdapter(sql, conn); // 实例化适配器
                    DataTable dt = new DataTable(); // 实例化数据表
                    myda.Fill(dt); // 保存数据 
                    dataGridView1.DataSource = dt; // 设置到DataGridView中
                    for (int i = 0; i < dataGridView1.ColumnCount; i++)
                    {
                        dataGridView1.Columns[i].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
                    }
                    conn.Close(); // 关闭数据库连接
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("错误信息：" + ex.Message, "出现错误");
            }

        }

        private void button3_Click(object sender, EventArgs e)
        {
            String connsql = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=Spj;Integrated Security=True";
            try
            {


                using (SqlConnection conn = new SqlConnection())
                {
                    conn.ConnectionString = connsql;
                    conn.Open();
                    SNO = this.textBox1.Text;
                    PNO = this.textBox2.Text;
                    QLT = this.textBox3.Text;
                    String sql = "DECLARE @retstat int; EXECUTE @retstat = STOCK" + "'" + SNO + "'" + "," + "'" + PNO + "'" + "," + "'J1'," +QLT+ "IF @retstat = 0 SELECT 'Stock success' ELSE SELECT 'Stock failed'";
                    SqlDataAdapter myda = new SqlDataAdapter(sql, conn); // 实例化适配器
                    DataTable dt = new DataTable(); // 实例化数据表
                    myda.Fill(dt); // 保存数据 
                    dataGridView1.DataSource = dt; // 设置到DataGridView中
                    for (int i = 0; i < dataGridView1.ColumnCount; i++)
                    {
                        dataGridView1.Columns[i].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
                    }
                    conn.Close(); // 关闭数据库连接
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("错误信息：" + ex.Message, "出现错误");
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            String connsql = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=Spj;Integrated Security=True";
            try
            {


                using (SqlConnection conn = new SqlConnection())
                {
                    conn.ConnectionString = connsql;
                    conn.Open();
                    String sql = "SELECT *FROM Orders";
                    SqlDataAdapter myda = new SqlDataAdapter(sql, conn); // 实例化适配器
                    DataTable dt = new DataTable(); // 实例化数据表
                    myda.Fill(dt); // 保存数据 
                    dataGridView1.DataSource = dt; // 设置到DataGridView中
                    for (int i = 0; i < dataGridView1.ColumnCount; i++)
                    {
                        dataGridView1.Columns[i].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
                    }
                    conn.Close(); // 关闭数据库连接
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("错误信息：" + ex.Message, "出现错误");
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {

            String connsql = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=Spj;Integrated Security=True";
            try
            {


                using (SqlConnection conn = new SqlConnection())
                {
                    conn.ConnectionString = connsql;
                    conn.Open();
                    String sql = "SELECT *FROM PURCHASE";
                    SqlDataAdapter myda = new SqlDataAdapter(sql, conn); // 实例化适配器
                    DataTable dt = new DataTable(); // 实例化数据表
                    myda.Fill(dt); // 保存数据 
                    dataGridView1.DataSource = dt; // 设置到DataGridView中
                    for (int i = 0; i < dataGridView1.ColumnCount; i++)
                    {
                        dataGridView1.Columns[i].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
                    }
                    conn.Close(); // 关闭数据库连接
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("错误信息：" + ex.Message, "出现错误");
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}

